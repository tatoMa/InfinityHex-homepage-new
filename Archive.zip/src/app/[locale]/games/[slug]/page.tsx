import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import Reveal from '@/components/Reveal'
import { formatCount, formatMoney, getAllGames, getGame } from '@/lib/games'
import { placeholderCover } from '@/lib/cover'
import { isLocale, locales, type Locale } from '@/i18n/config'
import { getDict } from '@/i18n/dict'

export async function generateStaticParams() {
  const games = await getAllGames()
  return locales.flatMap((locale) => games.map((g) => ({ locale, slug: g.slug })))
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string; slug: string }>
}): Promise<Metadata> {
  const { locale, slug } = await params
  if (!isLocale(locale)) return {}
  const g = await getGame(slug)
  if (!g) return {}
  const l = locale as Locale
  return {
    title: `${g.title[l]} · Infinity Hex Games`,
    description: g.tagline[l],
  }
}

export default async function GamePage({
  params,
}: {
  params: Promise<{ locale: string; slug: string }>
}) {
  const { locale, slug } = await params
  if (!isLocale(locale)) notFound()
  const l = locale as Locale
  const t = getDict(l)

  const games = await getAllGames()
  const idx = games.findIndex((x) => x.slug === slug)
  const g = games[idx]
  if (!g) notFound()

  const prev = games[idx - 1]
  const next = games[idx + 1]

  const cover =
    g.cover ??
    placeholderCover({
      title: g.title[l],
      subtitle: l === 'zh' ? g.title.en : '',
      tag: g.tags[l].join(' · '),
      color: g.color,
      index: idx,
    })

  const facts: { k: string; v: string; num?: boolean }[] = []
  if (g.players) facts.push({ k: t.games.players, v: g.players, num: true })
  if (g.time) facts.push({ k: t.games.time, v: `${g.time}′`, num: true })
  if (g.age) facts.push({ k: t.games.age, v: g.age, num: true })
  if (g.weight != null) facts.push({ k: t.games.weight, v: g.weight.toFixed(1), num: true })
  if (g.designer) facts.push({ k: t.games.designer, v: g.designer[l] })
  if (g.publisher) facts.push({ k: t.games.publisher, v: g.publisher[l] })

  return (
    <article className="detail">
      <div className="wrap">
        <Reveal as="p" style={{ marginBottom: 20 }}>
          <Link className="btn btn-g btn-sm" href={`/${l}#games`}>
            <span>← {t.games.back}</span>
          </Link>
        </Reveal>

        <div className="detail-hero">
          <Reveal>
            <div className="detail-art" style={{ ['--gc' as string]: g.color }}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={cover} alt={`${g.title[l]} ${g.title.en}`} width={300} height={420} />
            </div>
          </Reveal>

          <Reveal d={1} className="detail-head">
            <div className="detail-badges">
              {g.kind === 'original' ? (
                <span className="badge b-original">{t.games.original}</span>
              ) : (
                <span className="badge" style={{ border: '1px solid rgba(22,24,31,.14)' }}>
                  {t.games.localised}
                </span>
              )}
              <span className={`badge b-${g.status}`}>{t.games.status[g.status]}</span>
              {g.year ? (
                <span className="badge" style={{ border: '1px solid rgba(22,24,31,.14)' }}>
                  {g.year}
                </span>
              ) : null}
              {g.sample ? <span className="badge b-sample">{t.games.sample}</span> : null}
            </div>

            <h1>
              {g.title[l]}
              {l === 'zh' && g.title.en !== g.title.zh ? (
                <span className="alt" lang="en">
                  {g.title.en}
                </span>
              ) : null}
            </h1>
            <p className="detail-tag">{g.tagline[l]}</p>

            {g.funding ? (
              <div className="fund">
                <div>
                  <span>{t.games.raised}</span>
                  <b>{formatMoney(g.funding, l)}</b>
                </div>
                {g.funding.backers ? (
                  <div>
                    <span>{t.games.backers}</span>
                    <b>{formatCount(g.funding.backers, l)}</b>
                  </div>
                ) : null}
                {g.funding.stretch ? (
                  <div>
                    <span>{t.games.stretch}</span>
                    <b>{g.funding.stretch}</b>
                  </div>
                ) : null}
              </div>
            ) : null}

            {facts.length ? (
              <div className="factgrid">
                {facts.map((f) => (
                  <div key={f.k}>
                    <span>{f.k}</span>
                    <b className={f.num ? 'num' : ''}>{f.v}</b>
                  </div>
                ))}
              </div>
            ) : null}
          </Reveal>
        </div>

        <Reveal>
          {/* Markdown comes from our own content directory, not user input. */}
          <div className="prose" dangerouslySetInnerHTML={{ __html: g.body[l] }} />
        </Reveal>

        <nav className="detail-nav" aria-label={t.games.all}>
          {prev ? (
            <Link className="btn btn-g btn-sm" href={`/${l}/games/${prev.slug}`}>
              <span>← {prev.title[l]}</span>
            </Link>
          ) : (
            <span />
          )}
          {next ? (
            <Link className="btn btn-g btn-sm" href={`/${l}/games/${next.slug}`}>
              <span>{next.title[l]} →</span>
            </Link>
          ) : (
            <span />
          )}
        </nav>
      </div>
    </article>
  )
}
