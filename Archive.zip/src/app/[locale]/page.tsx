import { notFound } from 'next/navigation'
import Hero, { type HeroStat } from '@/components/hero/Hero'
import Catalogue from '@/components/sections/Catalogue'
import GameGrid from '@/components/sections/GameGrid'
import Partners, { type Partner } from '@/components/sections/Partners'
import Process from '@/components/sections/Process'
import HexWipe from '@/components/sections/HexWipe'
import DiceRail from '@/components/sections/DiceRail'
import { Contact, Services, Story } from '@/components/sections/Blocks'
import { getAllGames, getTotals, shortMoney } from '@/lib/games'
import { placeholderCover } from '@/lib/cover'
import { isLocale, type Locale } from '@/i18n/config'
import { getDict } from '@/i18n/dict'
import partnersData from '../../../content/partners.json'

const PAPER = '#F8F3E9'
const PAPER_HI = '#FDFAF3'
const INK = '#16181F'

export default async function Home({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params
  if (!isLocale(locale)) notFound()
  const l = locale as Locale
  const t = getDict(l)
  const games = await getAllGames()
  const totals = await getTotals()

  const money = shortMoney(totals.raised, totals.currency, l)
  const heroStats: HeroStat[] = [
    { key: 'raised',  n: money.n,        decimals: money.decimals, suffix: money.suffix,
      label: t.stats.raised.label,  sub: t.stats.raised.sub },
    { key: 'backers', n: totals.backers, decimals: 0, suffix: '',
      label: t.stats.backers.label, sub: t.stats.backers.sub },
    { key: 'stretch', n: totals.stretch, decimals: 0, suffix: '',
      label: t.stats.stretch.label, sub: t.stats.stretch.sub },
    { key: 'response', n: t.stats.response.n, decimals: 0, suffix: t.stats.response.suffix,
      label: t.stats.response.label, sub: t.stats.response.sub },
  ]

  const withCover = games.map((g, i) => ({
    ...g,
    resolvedCover:
      g.cover ??
      placeholderCover({
        title: g.title[l],
        subtitle: l === 'zh' ? g.title.en : '',
        tag: g.tags[l].join(' · '),
        color: g.color,
        index: i,
      }),
  }))

  const fanItems = withCover.map((g) => ({
    slug: g.slug,
    title: g.title[l],
    sub: g.tags[l].join(' · '),
    tag: g.tags[l].join(' · '),
    cover: g.resolvedCover,
  }))

  const tiles = withCover.map((g) => ({ title: g.title[l], cover: g.resolvedCover }))

  return (
    <>
      <DiceRail
        ids={['top', 'catalogue', 'games', 'process', 'services', 'partners', 'contact']}
        total={7}
      />

      <Hero t={t} locale={l} items={fanItems} stats={heroStats} titles={totals.titles} />

      <HexWipe from={PAPER} to={INK} dir="ltr" piece="meeple" />

      <Catalogue
        tiles={tiles}
        eyebrow={t.games.eyebrow}
        title={t.games.title}
        titleAlt={t.games.titleEn}
        lead={t.games.lead}
        cta={t.games.all}
        ctaHref="#games"
      />

      <HexWipe from={INK} to={PAPER} dir="rtl" piece="die" />

      <GameGrid games={games} locale={l} t={t} />

      <HexWipe from={PAPER} to={PAPER_HI} dir="center" rod="#C8352B" piece="meeple" />

      <div className="tint">
        <Process t={t} />
        <Services t={t} />
        <Partners
          partners={partnersData as Partner[]}
          locale={l}
          eyebrow={t.partners.eyebrow}
          title={t.partners.title}
          titleAlt={t.partners.titleEn}
          lead={t.partners.lead}
          cta={t.partners.cta}
          note={
            l === 'zh'
              ? '空白格是留给下一位伙伴的。标注为示例的格子，替换 content/partners.json 即可。'
              : 'The empty cells are waiting for the next partner. Sample cells are replaced in content/partners.json.'
          }
        />
      </div>

      <HexWipe from={PAPER_HI} to={PAPER} dir="ltr" piece="die" />

      <Story t={t} />
      <Contact t={t} />
    </>
  )
}
