'use client'

import { useEffect, useRef, useState } from 'react'

/**
 * Brand mark.
 *
 * Renders `/logo.png` when it exists and silently falls back to the inline
 * hex/infinity mark otherwise — so dropping the real file into `public/`
 * is the entire integration step, with no code change and no broken image
 * in the meantime.
 */
export default function Logo({ size = 40 }: { size?: number }) {
  const [failed, setFailed] = useState(false)
  const imgRef = useRef<HTMLImageElement>(null)

  // The server-rendered <img> can finish failing before React hydrates, and a
  // replayed error event is not guaranteed — so also check on mount.
  useEffect(() => {
    const el = imgRef.current
    if (el && el.complete && el.naturalWidth === 0) setFailed(true)
  }, [])

  if (!failed) {
    return (
      /* eslint-disable-next-line @next/next/no-img-element */
      <img
        ref={imgRef}
        className="brand-mark"
        src="/logo.png"
        alt=""
        width={size}
        height={size}
        style={{ objectFit: 'contain' }}
        onError={() => setFailed(true)}
      />
    )
  }

  return (
    <svg className="brand-mark" viewBox="0 0 100 100" width={size} height={size} aria-hidden="true">
      <defs>
        <linearGradient id="ihx-mark" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#E1594A" />
          <stop offset="1" stopColor="#A3271F" />
        </linearGradient>
      </defs>
      <path d="M50 3 92 26.5v47L50 97 8 73.5v-47z" fill="url(#ihx-mark)" />
      <path
        d="M50 12 84 31v38L50 88 16 69V31z"
        fill="none"
        stroke="#fff"
        strokeOpacity=".55"
        strokeWidth="1.6"
      />
      <path
        d="M34 50c0-6 4.6-10 10.2-10 7.8 0 11.6 10 11.6 10s3.8 10 11.6 10C73 60 77 56 77 50s-4-10-9.6-10C59.6 40 55.8 50 55.8 50S52 60 44.2 60C38.6 60 34 56 34 50z"
        fill="none"
        stroke="#fff"
        strokeWidth="5.4"
        strokeLinecap="round"
      />
    </svg>
  )
}
