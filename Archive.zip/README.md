# Infinity Hex Games 向量桌游 — 官网

Next.js 16 · React 19 · TypeScript · 零 CSS 框架（手写设计系统）

```bash
npm install
npm run dev      # http://localhost:3000
npm run build && npm start
```

Node ≥ 20.9。Turbopack 已是 Next 16 的默认构建器，无需 `--turbopack`。

---

## 1. 交付前必做的三件事

1. **放 logo**：把 `logo.png` 放进 `public/`（取自 https://www.infinityhex.com/logo.png）。
   `<Logo>` 组件先请求 `/logo.png`，取不到才回退到内置的 SVG 六边形标志——**不用改任何代码**，放进去就生效。（沙箱环境无法下载该二进制文件，所以仓库里目前是回退标志。）
2. **换掉示例游戏**：`content/games/` 里带 `sample: true` 的 6 个文件是占位，删掉或替换。卡片上的「示例数据」角标会随之消失。
3. **让法务过一遍** `src/content/legal.ts` 里的三份政策，并更新 `UPDATED` 日期与公司主体信息。它们如实描述了当前代码的行为，但仍是草稿。

---

## 2. 目录结构

```
content/
  games/*.md          ← 每个游戏一个文件（首页卡片 + 详情页都来自这里）
  partners.json       ← 合作伙伴蜂巢
public/
  logo.png            ← 你放进来的真实 logo（可选，缺失时自动回退）
src/
  proxy.ts            ← 语言路由（Next 16 把 middleware 改名为 proxy）
  app/[locale]/       ← 页面：首页 / games/[slug] / legal/[doc]
  components/         ← Hero、转场、区块、Cookie 同意
  content/legal.ts    ← 隐私 / Cookie / 条款
  i18n/               ← 语言配置与全站文案词典
  lib/games.ts        ← Markdown → 数据（build 时执行）
  styles/             ← base / hero / sections 三张表
```

---

## 3. 新增一个游戏

在 `content/games/` 里新建一个 `.md`，**下次 build 时首页卡片和详情页会自动出现**——没有注册表，不用改代码。

```markdown
---
slug: my-game            # 可省略，默认取文件名
order: 3                 # 排序
kind: original           # original | localised
status: funding          # shipping | funding | upcoming | licensing
color: "#1F6E64"         # 占位封面与强调色
cover: /games/my-game/cover.jpg   # 有真图就写这一行
sample: false            # true 时卡片显示「示例数据」角标
year: 2026
designer:                # 也可以只写一个字符串
  zh: 某某
  en: Someone
players: "2–4"
time: "60–90"
age: "12+"
weight: 3.2
funding:
  amount: 1284000
  currency: CNY
  backers: 3120
  stretch: 28
  platform:
    zh: 摩点
    en: Modian
title:
  zh: 中文名
  en: English Title
tagline:
  zh: 一句话介绍
  en: One-line pitch
tags:
  zh: [策略, 版图]
  en: [Strategy, Area control]
---

中文正文，正常 Markdown。

<!-- @en -->

English body. 缺这一段时会自动复用中文正文。
```

**一个文件装两种语言**，正文用 `<!-- @en -->` 这一行分隔（在任何 Markdown 编辑器里都不可见）。

### 首页数字是算出来的，不用手改

Hero 那一排「众筹总额 / 累计支持者 / 解锁目标」以及 kicker 里的项目数，全部由 `getTotals()` 在 build 时从所有 md 汇总。加一款游戏、改一个数字，首页自己就更新了。

**带 `sample: true` 的条目不计入金额、支持者、解锁目标**——占位数字绝不能进标题总计。但它们照常计入「项目数」，因为那只是目录里有几条。「平均响应 48 小时」不是能从 md 推出来的东西，仍留在 `dict.ts` 里。
封面留空时会用 `src/lib/cover.ts` 生成的 SVG 占位图，挂在真实的 `<img src>` 上——换真图就是换 `src`。
金额会按语言自动格式化：`¥199.6万` / `¥2.00M`。
`designer` / `publisher` / `funding.platform` 既可以写成一个字符串，也可以写成 `{ zh, en }`——英文页就不会再冒出中文。

---

## 4. 中英双语

- 路由是 `/zh` 与 `/en`，两种语言都在 build 时静态生成。
- `src/proxy.ts` 在边缘处理 `/` → `/zh` 或 `/en`：**先看 `ihx_locale` cookie，没有就解析 `Accept-Language`**（带 q 权重；中文任意变体 → zh，其余 → en）。深链接会被完整保留：`/games/agemonia` → `/en/games/agemonia`。
- 导航栏的「中 / EN」开关写 cookie 后跳到对应语言的同一页面。
- 界面文案在 `src/i18n/dict.ts`，游戏文案在 md 里，两者互不干扰。

---

## 5. Cookie 与合规

以欧盟口径为基线（同时满足美国各州法）：

- 非必要 Cookie **在明确同意前一个都不设**。
- 分类颗粒化，**默认全关**，没有预勾选。
- 「全部拒绝」与「全部接受」**同样大小、同样显眼、同样一步到位**（已实测两个按钮的类名与宽度完全一致）。
- 页脚「Cookie 设置」随时可撤回；另有「不出售或共享我的个人信息」入口（CPRA）。
- 同意记录带版本号与时间戳，180 天后重新询问。
- **尊重 GPC 信号**：浏览器发送 `Sec-GPC: 1` / `navigator.globalPrivacyControl` 时，自动记为拒绝并且不弹窗。

接分析工具时，**不要无条件加载**，挂到同意事件上：

```js
window.addEventListener('ihx:consent', (e) => {
  if (e.detail.analytics) loadAnalytics()
})
// 已经同意过的老访客：
if (window.__ihxConsent?.analytics) loadAnalytics()
```

当前站点确实没有装任何分析或广告脚本——Cookie 政策里是这么写的，加工具前请同步更新那一段。

---

## 6. 动效与性能

- **一个 rAF 循环**（`src/components/Motion.tsx`）供全站订阅；没有订阅者时自动停摆。
- **一个滚动数据源**：只有一个 passive 监听器，它只记录 `scrollY`，不读布局；所有 `getBoundingClientRect` / `offsetTop` 都在 rAF 回调里读，天然批处理。（之前是五个组件各自监听 + 各自读布局 = 每次滚动五次强制重排，这是卡顿的主因之一。）
- 没有动效开关按钮——系统 `prefers-reduced-motion` 就是唯一开关。关掉是真静止：牌弧变静态弧、墙变静态网格、canvas 停笔、转场直接隐藏。
- 所有动画只碰 `transform` / `opacity`；canvas 限 DPR ≤ 1.5，离屏时直接 `visibility:hidden`（不只是停止绘制，连图层都不再合成）。
- 六边形晶格拆成两张 canvas，静态底图只画一次，上层只画亮起的格子。
- **晶格的渐隐是画进像素里的，不是 CSS mask**。用 `mask-image` 遮一张全屏 canvas，会让浏览器每帧重新合成一整个带遮罩的图层——实测这是全页面最贵的一件事。改成在绘制时按同样的曲线乘 alpha，代价为零。
- 图片墙原本用两层 mask + `mask-composite` 罩在一个 3D 子树上，同样很贵；现在只保留水平方向的 mask，垂直渐隐改用普通渐变层。
- `content-visibility:auto` 试过又**撤掉了**：它的 `contain-intrinsic-size` 是个估值，于是每个第一次滚进视口的 section 都会改变文档高度、把下面的东西整体推走——锚点会漂、滚动条会跳。它省下的那点开销远不及 canvas 那一刀，正确性优先。

实测（同一台机、同一浏览器，全页滚动 150 帧）：中位帧间隔 **33.4ms → 16.7ms**，超过 32ms 的帧 **125 → 40**。JS 自身开销一直只有 1.1–1.7ms/帧，瓶颈从来不在逻辑，在合成。

### 无障碍

- 图片墙 100 张 tile 全部 `aria-hidden`，读屏用户拿到墙上方一份干净的目录列表——不会被 100 个 tab 停靠点淹没。
- 灰阶 token 按 WCAG AA 校准过；跳转链接、朱砂焦点环、语义标签、`lang` 标注齐全。
- 系统开启「减少动态效果」后全站真静止，不是"动画变快"。

### 段落转场：落子

上一版是翻面色带，动画跑完之后留下一条平平的条子——那是"动画的残留"，不是设计。这一版反过来做：**静止状态才是设计**。

两个 section 沿一条互锁的六边形边界相接（上一节的色块被压成一排半嵌的六角）。接缝进入视口时这排格子还不在，它们从上方一枚枚落下、带一点回弹地就位，直到互锁完成。动画结束后什么都没剩下，因为被动画进来的那条边界本身就是最终形态。中央那枚格子上站着一个**米宝或骰子**（`piece="meeple" | "die"`，页面上交替）。

**每一格都装着一件配件**——米宝、六面骰、木块、卡牌、六角 token、棋子、八面骰、金币、沙漏，循环取用；中央那格放你在 `piece` 里指定的那个，尺寸大一号、颜色更实。图标颜色按上一节的底色亮度自动切明暗（亮底用泥金，暗底用宣纸白），所以同一个组件在明暗接缝上都成立。

一条接缝 = 1 个矩形 + 约 20 个 clip-path 六角，靠一次 class 切换 + CSS `transition-delay` 阶梯驱动，每帧零开销。

### 滚动叙事：铺开一局（`<Process>`）

340vh 的滚动跑道 + sticky 舞台。往下滚时：六边形棋盘**从中心一格格发出来**、卡牌／米宝／木块／骰子分五层以不同速率视差移动、左侧四步文案随之推进。全部挂在**一个**滚动进度值上（在共享 rAF 里读），没有额外监听器。棋盘每一格用 `clamp()` 把自己那一小段进度换算成落位与缩放，纯 CSS 计算。

减少动效时它塌成一块完整的棋盘 + 一个普通四项列表。

**它在每个尺寸上都是同一套 scrollytelling**，只换排布和视差幅度，而不是在小屏退化成静态堆叠：

| 断点 | 排布 |
|---|---|
| ≥1081 | 左文右图两栏，视差 ×1 |
| 1080↓ 竖屏（iPad 竖放） | 标题 → 舞台 → 四步，竖排居中，视差 ×0.52 |
| 1080↓ **横屏**（iPad 横放、小笔电） | 屏幕宽而矮，重新回到两栏 |
| ≤640 手机 | 标题 → 舞台 → **只显示当前一步** + 四段进度条，视差 ×0.34 |
| ≤640 且高 ≤700（SE / 手机横屏） | 舞台再缩一档 |

舞台的尺寸**只由宽度决定**（`width:min(100%, var(--art))` + `aspect-ratio:1/1`）。中途试过配 `max-height`，结果宽高比失去可解析的确定轴、整个盒子塌成 0 高——别再加回去。

### 滚动进度：骰子（以及 6 节以上怎么办）

右侧的 `<DiceRail>` 不是进度条，是真的骰子。d6 只能数到 6，所以它按页面长度自己换器具——就像在真桌子上一样：

| section 数 | 显示 |
|---|---|
| ≤ 6 | 一颗 d6，骰面就是第几节 |
| 7–12 | **两颗 d6 相加**（第 9 节 = 5 + 4） |
| > 12 | 一枚会翻面的编号六角 token——骰子隐喻体面退场，而不是假装自己数得过来 |

加 section 时不用改组件，它自己切换；旁边的 `NN/NN` 一直在，永远不会产生歧义。

---

## 7. iPad 上的三卡片问题

三个等宽列在平板上太挤，两列又会剩一个孤儿。`.trio` 的解法是：**700–1179px 之间，第一张卡变成整行的横向 feature，剩下两张并排**，正好填满、没有孤儿。见 `src/styles/sections.css` 的 `.trio`。
游戏网格用的是 `auto-fill minmax(258px, 1fr)`，条目多时自然流动，不受此限。

---

## 8. Hero 的牌弧

牌弧**故意溢出栏位**：`.hero-stage` 带负 margin 顶出页面 gutter，最右一张牌被 `.hero{overflow:hidden}` 裁掉一半——设计上就是要它冲出框。

卡片之间**不设 z-index**。整个扇形在 `preserve-3d` 上下文里，浏览器按各自真实的 `translateZ` 排序，而 translateZ 随弧度连续变化。之前用整数 z-index 是它们滚动时会"跳层"的原因。

进出场用一个 `life` 值（smoothstep，`EDGE`/`FADE` 两个常数控制）**同时**驱动透明度、缩放和 Z——所以一张牌是"走过来"的，不是"出现"的。实测每帧透明度最大变化 0.064、缩放 0.011，接缝处不会再有突变。

**整副牌在页面滚动时不淡出。** 它只跟着页面往上飘一点点，透明度始终是 1——哪怕屏幕顶端只剩一角，那一角也还是清清楚楚的牌。只有当它完全离开视口时，`IntersectionObserver` 才让它停下来歇着（threshold 0 = 只要露出一丝就继续活着）。

---

## 9. 响应式

实测过的断点：320 / 360 / 390 / 430 / 600 / 768 / 834 / 1024 / 1180 / 1280 / 1512 / 1920 / 2560，每个都从头滚到尾检查——**没有任何一处横向溢出**，触摸尺寸下也没有小于 26px 的可点区域。

有两个元素会"越界"但是故意的，且都被父级裁掉了：`.wall-glow`（在 `overflow:hidden` 的暗色区里做光晕漂移）和蜂巢格上的 `.glint`（被 `clip-path` 裁在六角内）。

---

## 10. 已知取舍

- 图片墙的 5 行会重复现有封面来填满行宽；作品超过约 10 个后重复感会自然消失。
- 合作伙伴的占位标是程序生成的字母标；把真 logo 放进 `public/partners/` 并在 `content/partners.json` 里写 `logo` 字段即可替换。
- `Agemonia` 的设计师字段写的是「待补充 / TBD」——公开资料没查到可靠信息，没有编造。
