'use client'

import { useEffect, useRef, useState } from 'react'
import { clamp, lerp, scrollState, useFrame, useMotion } from '../Motion'
import type { Dict } from '@/i18n/dict'

/**
 * 长桌 — the company history, told as a hand of cards laid out along a table.
 *
 * The section is tall; its stage is sticky. Vertical scroll drives the rail
 * horizontally, so the milestones travel past a fixed playhead in the middle
 * of the screen. Each card knows its own signed distance from that playhead
 * (`--d`) and uses it to rotate, recede in Z and fade — so the row reads as a
 * real perspective row of objects rather than a list that slides.
 *
 * Behind it: a hex mesh and three colour washes on three different parallax
 * rates, plus the year set in enormous type, cross-fading as each milestone
 * takes the playhead.
 *
 * Everything hangs off ONE progress number read inside the shared frame loop.
 * With reduced motion the whole thing collapses (see `body.no-mo .hist` in
 * sections.css) into a normal horizontally scrollable strip.
 */
export default function History({ t }: { t: Dict }) {
  const items = t.history.items

  const secRef = useRef<HTMLElement>(null)
  const vpRef = useRef<HTMLDivElement>(null)
  const railRef = useRef<HTMLDivElement>(null)
  const meshRef = useRef<HTMLDivElement>(null)
  const washRef = useRef<HTMLDivElement>(null)
  const barRef = useRef<HTMLElement>(null)

  const [step, setStep] = useState(0)
  const { motion } = useMotion()

  const p = useRef({ cur: 0, tgt: 0 })
  /** measured once per resize: node pitch, side padding, total travel */
  const geo = useRef({ nw: 320, gap: 24, pad: 0, travel: 1, vpw: 1 })

  useEffect(() => {
    const vp = vpRef.current
    const rail = railRef.current
    if (!vp || !rail) return

    const measure = () => {
      const first = rail.querySelector('.hist-node') as HTMLElement | null
      if (!first) return
      const vpw = vp.clientWidth || 1
      const nw = first.offsetWidth
      const gap = parseFloat(getComputedStyle(rail).columnGap || '24') || 24
      // Centre the first and last card under the playhead at p = 0 and p = 1.
      const pad = Math.max(0, (vpw - nw) / 2)
      rail.style.setProperty('--pad', `${pad.toFixed(1)}px`)
      const total = pad * 2 + items.length * nw + (items.length - 1) * gap
      geo.current = { nw, gap, pad, vpw, travel: Math.max(1, total - vpw) }
    }

    measure()
    const ro = new ResizeObserver(measure)
    ro.observe(vp)
    return () => ro.disconnect()
  }, [items.length])

  useFrame((dt) => {
    const sec = secRef.current
    const rail = railRef.current
    const vp = vpRef.current
    if (!sec || !rail || !vp) return

    const travelY = sec.offsetHeight - scrollState.vh
    const raw = travelY > 0 ? (scrollState.y - sec.offsetTop) / travelY : 0
    // A short lead-in and lead-out keeps the first and last card readable
    // instead of snapping the moment the section pins.
    p.current.tgt = clamp((raw - 0.08) / 0.84, 0, 1)

    if (!motion) {
      const n = clamp(Math.round(p.current.tgt * (items.length - 1)), 0, items.length - 1)
      setStep((s) => (s === n ? s : n))
      return
    }

    p.current.cur = lerp(p.current.cur, p.current.tgt, 1 - Math.pow(0.0022, dt / 1000))
    const v = p.current.cur
    const g = geo.current

    rail.style.transform = `translate3d(${(-v * g.travel).toFixed(1)}px,0,0)`

    // playhead position, expressed in rail coordinates
    const head = v * g.travel + g.vpw / 2
    const nodes = rail.children
    let best = 0
    let bestD = Infinity
    for (let i = 0; i < nodes.length; i++) {
      const el = nodes[i] as HTMLElement
      if (!el.classList.contains('hist-node')) continue
      const idx = Number(el.dataset.i)
      const centre = g.pad + idx * (g.nw + g.gap) + g.nw / 2
      const d = (centre - head) / g.vpw
      const ad = Math.abs(d)
      el.style.setProperty('--d', d.toFixed(4))
      el.style.setProperty('--ad', ad.toFixed(4))
      if (ad < bestD) {
        bestD = ad
        best = idx
      }
    }
    setStep((s) => (s === best ? s : best))

    if (barRef.current) barRef.current.style.width = `${(v * 100).toFixed(2)}%`
    if (meshRef.current)
      meshRef.current.style.transform = `translate3d(${(-v * 260).toFixed(1)}px,0,0)`
    if (washRef.current)
      washRef.current.style.transform =
        `translate3d(${(v * 150 - 75).toFixed(1)}px,${(v * 40 - 20).toFixed(1)}px,0) scale(1.12)`
  })

  return (
    <section className="sec hist on-dark on-dark-rail" id="history" ref={secRef} aria-labelledby="histTitle">
      <div className="hist-sticky">
        <div className="hist-bg" aria-hidden="true">
          <div className="hist-wash" ref={washRef} />
          <div className="hist-mesh" ref={meshRef} />
        </div>

        {/* the year, set enormous, behind everything */}
        <div className="hist-ghost" aria-hidden="true">
          {items.map((it, i) => (
            <span key={i} className={i === step ? 'on' : i < step ? 'past' : ''}>
              {it.y}
            </span>
          ))}
        </div>

        <div className="wrap hist-head">
          <p className="eyebrow">
            <span className="hx" />
            {t.history.eyebrow}
          </p>
          <h2 className="sec-title" id="histTitle">
            {t.history.title}
            <span className="alt">{t.history.titleEn}</span>
          </h2>
          <p className="hist-lead">{t.history.lead}</p>
        </div>

        <div className="hist-viewport" ref={vpRef}>
          <div className="hist-rail" ref={railRef}>
            {items.map((it, i) => (
              <article className="hist-node" key={i} data-i={i} style={{ ['--i' as string]: i }}>
                <span className="hist-tok" aria-hidden="true">
                  <i>{String(i + 1).padStart(2, '0')}</i>
                </span>
                <div className="hist-card">
                  <span className="hist-when">
                    {it.y}
                    <em>{it.q}</em>
                  </span>
                  <h3>
                    {it.t}
                    <span className="alt">{it.en}</span>
                  </h3>
                  <p>{it.d}</p>
                </div>
              </article>
            ))}
          </div>

          {/* the playhead: the rail moves, this stays put */}
          <span className="hist-playhead" aria-hidden="true" />
        </div>

        <div className="hist-foot">
          <ol className="hist-pips" aria-hidden="true">
            {items.map((it, i) => (
              <li key={i} className={i <= step ? 'on' : ''}>
                <span>{it.y}</span>
              </li>
            ))}
          </ol>
          <div className="hist-bar">
            <b ref={barRef} />
          </div>
        </div>
      </div>
    </section>
  )
}
